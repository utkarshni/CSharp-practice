﻿using HOLProductManagementDemo.Entities;
using ProductManagementDemo.API.Entities;

namespace HOLProductManagementDemo.Helpers.Extensions
{
    public static class ProductExtensions
    {
        public static decimal CalculateSavings(this Product product)
        {
            if (product.DiscountedPrice == null)
                return 0;

            return product.Price - product.DiscountedPrice.Value;
        }
    }
}
