﻿namespace HOLProductManagementDemo.Helpers.QueryObjects
{
    public class ProductQuery
    {
        public string? Name { get; set; }

        public int? CategoryId { get; set; }

        public bool? IsFeatured { get; set; }

        public decimal? MinPrice { get; set; }

        public decimal? MaxPrice { get; set; }
    }
}
