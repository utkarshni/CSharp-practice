﻿using System.ComponentModel.DataAnnotations;

namespace ProductManagementDemo.API.DTOs
{

    public class ProductDetailDto
    {
        public int Id { get; set; }

        public string Name { get; set; } = "";

        public string Description { get; set; } = "";

        public decimal Price { get; set; }

        public decimal? DiscountedPrice { get; set; }

        public decimal Savings => Price - (DiscountedPrice ?? Price);

        public int DiscountPercentage =>
            DiscountedPrice.HasValue ?
            (int)((Price - DiscountedPrice.Value) / Price * 100) : 0;

        public bool IsActive { get; set; }

        public bool IsFeatured { get; set; }

        public double AverageRating { get; set; }

        public int ReviewCount { get; set; }
    }

    public class ProductSummaryDto
    {
        public int Id { get; set; }

        public string Name { get; set; } = "";

        public decimal Price { get; set; }

        public decimal? DiscountedPrice { get; set; }

        public double AverageRating { get; set; }

        public int ReviewCount { get; set; }
    }

    public class CreateProductDto
    {
        [Required]
        [StringLength(100)]
        public string Name { get; set; } = "";

        [StringLength(500)]
        public string Description { get; set; } = "";

        [Required]
        [Range(0.01, double.MaxValue)]
        public decimal Price { get; set; }

        public decimal? DiscountedPrice { get; set; }

        [Required]
        public int CategoryId { get; set; }

        public string Sku { get; set; } = "";
    }

    public class UpdateProductDto
    {
        public string? Name { get; set; }

        public decimal? Price { get; set; }

        public decimal? DiscountedPrice { get; set; }

        public bool? IsActive { get; set; }

        public bool? IsFeatured { get; set; }
    }

}
