﻿using HOLProductManagementDemo.DTOs;
using HOLProductManagementDemo.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using ProductManagementDemo.API.DTOs;
using ProductManagementDemo.API.Services.Interfaces;

namespace HOLProductManagementDemo.Controllers
{
    [ApiController]
    [Route("api/products")]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _service;

        public ProductsController(IProductService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var products = _service.GetAll();
            return Ok(products);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var product = _service.GetById(id);

            if (product == null)
                return NotFound();

            return Ok(product);
        }

        [HttpPost]
        public IActionResult Create(CreateProductDto dto)
        {
            var product = _service.Create(dto);
            return Ok(product);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateProductDto dto)
        {
            _service.Update(id, dto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _service.Delete(id);
            return NoContent();
        }
    }
}
