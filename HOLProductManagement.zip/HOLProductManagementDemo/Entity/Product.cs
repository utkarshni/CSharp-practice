﻿namespace ProductManagementDemo.API.Entities
{
    public class Product
    {
        public int Id { get; set; }

        public string Name { get; set; } = "";

        public string Description { get; set; } = "";

        public decimal Price { get; set; }

        public decimal? DiscountedPrice { get; set; }

        public int CategoryId { get; set; }

        public string SKU { get; set; } = "";

        public bool IsActive { get; set; } = true;

        public bool IsFeatured { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }

        public int ViewCount { get; set; }

        public int SoldCount { get; set; }

        public double AverageRating { get; set; }

        public int ReviewCount { get; set; }
    }
}
