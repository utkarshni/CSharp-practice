﻿namespace HOLProductManagementDemo.Services
{
    public class ProductService
    {
    }
}
