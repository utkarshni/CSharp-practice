﻿using ProductManagementDemo.API.DTOs;

namespace ProductManagementDemo.API.Services.Interfaces
{
    public interface IProductService
    {
        IEnumerable<ProductSummaryDto> GetAll();

        ProductDetailDto? GetById(int id);

        ProductDetailDto Create(CreateProductDto dto);

        void Update(int id, UpdateProductDto dto);

        void Delete(int id);
    }
}
