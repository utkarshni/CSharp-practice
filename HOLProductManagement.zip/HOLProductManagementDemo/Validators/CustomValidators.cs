﻿namespace HOLProductManagementDemo.Validators
{
    public static class CustomValidators
    {
        public static bool IsValidPrice(decimal price)
        {
            return price > 0;
        }

        public static bool IsValidDiscount(decimal price, decimal? discountedPrice)
        {
            if (discountedPrice == null)
                return true;

            return discountedPrice < price;
        }
    }
}
