﻿using Microsoft.EntityFrameworkCore;
using ProductManagementDemo.API.Entities;
using System.Collections.Generic;

namespace ProductManagementDemo.API.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
    }
}
