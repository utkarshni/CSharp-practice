﻿namespace HOLProductManagementDemo.Mapping
{
    public class MappingProfile
    {
    }
}
