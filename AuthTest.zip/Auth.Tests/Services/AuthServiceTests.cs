﻿using Xunit;
using Auth.API.Services;
using Auth.API.Data;
using Auth.API.Models;
using Auth.API.Helpers;
using Microsoft.EntityFrameworkCore;
using FluentAssertions;
using Microsoft.Extensions.Configuration;

namespace Auth.Tests.Services
{
    public class AuthServiceTests
    {
        private AuthDbContext GetDbContext()
        {
            var options = new DbContextOptionsBuilder<AuthDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new AuthDbContext(options);
        }

        private JwtTokenGenerator GetJwt()
        {
            var settings = new Dictionary<string, string>
    {
        {"JwtSettings:SecretKey", "THIS_IS_A_SUPER_LONG_SECRET_KEY_FOR_TESTING_1234567890_ABCDE_1234567890"},
        {"JwtSettings:Issuer", "TestIssuer"},
        {"JwtSettings:Audience", "TestAudience"},
        {"JwtSettings:ExpiryMinutes", "60"} // ⚠️ REQUIRED (you used Convert.ToDouble)
    };

            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(settings)
                .Build();

            return new JwtTokenGenerator(configuration);
        }

        // ✅ Helper to create valid user
        private User GetValidUser(string email = "test@mail.com", string password = "1234")
        {
            return new User
            {
                Username = "testuser",
                Email = email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(password),
                Role = "User",
                IsActive = true
            };
        }

        [Fact]
        public async Task Register_ShouldCreateUser_WhenValid()
        {
            var context = GetDbContext();
            var jwt = GetJwt();
            var service = new AuthService(context, jwt);

            var result = await service.Register("test", "test@mail.com", "1234", "User");

            result.Should().NotBeNull();
            result.Email.Should().Be("test@mail.com");
        }

        [Fact]
        public async Task Register_ShouldThrow_WhenUserExists()
        {
            var context = GetDbContext();
            var jwt = GetJwt();

            context.Users.Add(GetValidUser());
            await context.SaveChangesAsync();

            var service = new AuthService(context, jwt);

            await Assert.ThrowsAsync<Exception>(() =>
                service.Register("test", "test@mail.com", "1234", "User"));
        }

        [Fact]
        public async Task Login_ShouldReturnToken_WhenValid()
        {
            var context = GetDbContext();
            var jwt = GetJwt();

            context.Users.Add(GetValidUser());
            await context.SaveChangesAsync();

            var service = new AuthService(context, jwt);

            var result = await service.Login("test@mail.com", "1234");

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task Login_ShouldThrow_WhenInvalidPassword()
        {
            var context = GetDbContext();
            var jwt = GetJwt();

            context.Users.Add(GetValidUser(password: "correct"));
            await context.SaveChangesAsync();

            var service = new AuthService(context, jwt);

            await Assert.ThrowsAsync<Exception>(() =>
                service.Login("test@mail.com", "wrong"));
        }

        [Fact]
        public async Task ForgotPassword_ShouldReturnToken()
        {
            var context = GetDbContext();
            var jwt = GetJwt();

            context.Users.Add(GetValidUser());
            await context.SaveChangesAsync();

            var service = new AuthService(context, jwt);

            var token = await service.ForgotPassword("test@mail.com");

            token.Should().NotBeNull();
        }

        [Fact]
        public async Task ResetPassword_ShouldUpdatePassword()
        {
            var context = GetDbContext();
            var jwt = GetJwt();

            var user = GetValidUser();
            user.ResetPasswordToken = "token";
            user.ResetPasswordExpiry = DateTime.UtcNow.AddMinutes(30);

            context.Users.Add(user);
            await context.SaveChangesAsync();

            var service = new AuthService(context, jwt);

            var result = await service.ResetPassword("token", "newpass");

            result.Should().Be("Password reset successful");
        }
    }
}
