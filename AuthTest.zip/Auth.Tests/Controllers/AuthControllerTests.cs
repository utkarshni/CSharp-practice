﻿using Xunit;
using Moq;
using Auth.API.Controllers;
using Auth.API.Services;
using Auth.API.DTOs;
using Microsoft.AspNetCore.Mvc;
using FluentAssertions;

namespace Auth.Tests.Controllers
{
    public class AuthControllerTests
    {
        private readonly Mock<IAuthService> _serviceMock;
        private readonly AuthController _controller;

        public AuthControllerTests()
        {
            _serviceMock = new Mock<IAuthService>();
            _controller = new AuthController(_serviceMock.Object);
        }

        [Fact]
        public async Task Register_ShouldReturnOk_WithUser()
        {
            var dto = new RegisterDTO
            {
                FullName = "Test",
                Email = "test@mail.com",
                Password = "1234",
                Role = "User"
            };

            _serviceMock.Setup(x => x.Register(
                dto.FullName, dto.Email, dto.Password, dto.Role))
                .ReturnsAsync(new Auth.API.Models.User { Email = dto.Email });

            var result = await _controller.Register(dto);

            var okResult = result as OkObjectResult;

            okResult.Should().NotBeNull();
            okResult.Value.Should().BeEquivalentTo(new { email = dto.Email }, options =>
                options.ExcludingMissingMembers());
        }

        [Fact]
        public async Task Register_ShouldReturnBadRequest_OnException()
        {
            var dto = new RegisterDTO
            {
                FullName = "Test",
                Email = "test@mail.com",
                Password = "1234",
                Role = "User"
            };

            _serviceMock.Setup(x => x.Register(
                dto.FullName, dto.Email, dto.Password, dto.Role))
                .ThrowsAsync(new Exception("User exists"));

            var result = await _controller.Register(dto);

            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task Login_ShouldReturnToken()
        {
            var dto = new LoginDTO
            {
                Email = "test@mail.com",
                Password = "1234"
            };

            _serviceMock.Setup(x => x.Login(dto.Email, dto.Password))
                .ReturnsAsync("token");

            var result = await _controller.Login(dto);

            var okResult = result as OkObjectResult;

            okResult.Should().NotBeNull();

            // ✅ MUST MATCH controller response
            okResult.Value.Should().BeEquivalentTo(new { token = "token" });
        }

        [Fact]
        public async Task Login_ShouldReturnBadRequest_OnException()
        {
            var dto = new LoginDTO
            {
                Email = "wrong",
                Password = "wrong"
            };

            _serviceMock.Setup(x => x.Login(dto.Email, dto.Password))
                .ThrowsAsync(new Exception("Invalid"));

            var result = await _controller.Login(dto);

            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task Logout_ShouldReturnOk()
        {
            var dto = new LogoutDTO { Email = "test@mail.com" };

            _serviceMock.Setup(x => x.Logout(dto.Email))
                .Returns(Task.CompletedTask);

            var result = await _controller.Logout(dto);

            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task RefreshToken_ShouldReturnOk_WithToken()
        {
            var dto = new RefreshTokenDto { RefreshToken = "abc" };

            _serviceMock.Setup(x => x.RefreshToken(dto.RefreshToken))
                .ReturnsAsync("new-token");

            var result = await _controller.RefreshToken(dto);

            var okResult = result as OkObjectResult;

            okResult.Should().NotBeNull();

            // ✅ MUST MATCH controller response
            okResult.Value.Should().BeEquivalentTo(new { token = "new-token" });
        }
    }
}


            