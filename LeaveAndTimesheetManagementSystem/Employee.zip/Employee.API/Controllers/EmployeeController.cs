﻿using Employee.API.Models;
using Employee.API.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace Employee.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeRepository _repository;

        public EmployeeController(IEmployeeRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<IActionResult> GetEmployees()
        {
            var employees = await _repository.GetAllEmployees();
            return Ok(employees);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetEmployee(int id)
        {
            var employee = await _repository.GetEmployeeById(id);

            if (employee == null)
                return NotFound();

            return Ok(employee);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEmployee(Employee.API.Models.Employee employee)
        {
            var createdEmployee = await _repository.CreateEmployee(employee);
            return Ok(createdEmployee);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateEmployee(Employee.API.Models.Employee employee)
        {
            var updatedEmployee = await _repository.UpdateEmployee(employee);
            return Ok(updatedEmployee);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            var result = await _repository.DeleteEmployee(id);

            if (!result)
                return NotFound();

            return Ok("Employee deleted successfully");
        }
    }
}