﻿using Employee.API.Models;

namespace Employee.API.Repositories
{
    public interface IEmployeeRepository
    {
        Task<IEnumerable<Employee.API.Models.Employee>> GetAllEmployees();
        Task<Employee.API.Models.Employee> GetEmployeeById(int id);
        Task<Employee.API.Models.Employee> CreateEmployee(Employee.API.Models.Employee employee);
        Task<Employee.API.Models.Employee> UpdateEmployee(Employee.API.Models.Employee employee);
        Task<bool> DeleteEmployee(int id);
    }
}
