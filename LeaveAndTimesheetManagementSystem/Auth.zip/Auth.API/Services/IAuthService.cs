﻿using Auth.API.Models;

namespace Auth.API.Services
{
    public interface IAuthService
    {
        Task<User> Register(string fullName, string email, string password, string role);

        Task<string> Login(string email, string password);
        Task<User> CreateUser(string fullName, string email, string password, string role);

        Task<string> ForgotPassword(string email);

        Task<string> ResetPassword(string token, string newPassword);

        Task Logout(string email);

        Task<string> RefreshToken(string refreshToken);

        Task DeactivateUser(int userId);

        Task ReactivateUser(int userId);
    }
}
