﻿using Auth.API.Data;
using Auth.API.Helpers;
using Auth.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Auth.API.Services
{
    public class AuthService : IAuthService
    {
        private readonly AuthDbContext _context;
        private readonly JwtTokenGenerator _jwt;

        public AuthService(AuthDbContext context, JwtTokenGenerator jwt)
        {
            _context = context;
            _jwt = jwt;
        }

        // REGISTER
        public async Task<User> Register(string username, string email, string password, string role)
        {
            var userExists = await _context.Users.AnyAsync(x => x.Email == email);

            if (userExists)
                throw new Exception("User already exists");

            var user = new User
            {
                Username = username,
                Email = email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(password),
                Role = role,
                IsActive = true
            };

            _context.Users.Add(user);

            await _context.SaveChangesAsync();

            return user;
        }

        // LOGIN
        public async Task<string> Login(string email, string password)
        {
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Email == email);

            if (user == null || !user.IsActive)
                throw new Exception("Invalid credentials");

            bool validPassword = BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);

            if (!validPassword)
                throw new Exception("Invalid credentials");

            var token = _jwt.GenerateToken(user);

            // Generate refresh token
            user.RefreshToken = Guid.NewGuid().ToString();
            user.RefreshTokenExpiry = DateTime.UtcNow.AddDays(7);

            await _context.SaveChangesAsync();

            return token;
        }

        // CREATE USER (Admin use)
        public async Task<User> CreateUser(string username, string email, string password, string role)
        {
            var userExists = await _context.Users.AnyAsync(x => x.Email == email);

            if (userExists)
                throw new Exception("User already exists");

            var user = new User
            {
                Username = username,
                Email = email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(password),
                Role = role,
                IsActive = true
            };

            _context.Users.Add(user);

            await _context.SaveChangesAsync();

            return user;
        }

        // FORGOT PASSWORD
        public async Task<string> ForgotPassword(string email)
        {
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Email == email);

            if (user == null)
                throw new Exception("User not found");

            var resetToken = Guid.NewGuid().ToString();

            user.ResetPasswordToken = resetToken;
            user.ResetPasswordExpiry = DateTime.UtcNow.AddHours(1);

            await _context.SaveChangesAsync();

            return resetToken;
        }

        // RESET PASSWORD
        public async Task<string> ResetPassword(string token, string newPassword)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(x => x.ResetPasswordToken == token);

            if (user == null || user.ResetPasswordExpiry < DateTime.UtcNow)
                throw new Exception("Invalid or expired token");

            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(newPassword);

            user.ResetPasswordToken = null;
            user.ResetPasswordExpiry = null;

            await _context.SaveChangesAsync();

            return "Password reset successful";
        }

        // LOGOUT
        public async Task Logout(string email)
        {
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Email == email);

            if (user == null)
                throw new Exception("User not found");

            user.RefreshToken = null;
            user.RefreshTokenExpiry = null;

            await _context.SaveChangesAsync();
        }

        // REFRESH TOKEN
        public async Task<string> RefreshToken(string refreshToken)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(x => x.RefreshToken == refreshToken);

            if (user == null || user.RefreshTokenExpiry < DateTime.UtcNow)
                throw new Exception("Invalid refresh token");

            var newJwt = _jwt.GenerateToken(user);

            user.RefreshToken = Guid.NewGuid().ToString();
            user.RefreshTokenExpiry = DateTime.UtcNow.AddDays(7);

            await _context.SaveChangesAsync();

            return newJwt;
        }

        // DEACTIVATE USER
        public async Task DeactivateUser(int userId)
        {
            var user = await _context.Users.FindAsync(userId);

            if (user == null)
                throw new Exception("User not found");

            user.IsActive = false;

            await _context.SaveChangesAsync();
        }

        // REACTIVATE USER
        public async Task ReactivateUser(int userId)
        {
            var user = await _context.Users.FindAsync(userId);

            if (user == null)
                throw new Exception("User not found");

            user.IsActive = true;

            await _context.SaveChangesAsync();
        }
    }
}
/*using Auth.API.Data;
using Auth.API.Helpers;
using Auth.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Auth.API.Services
{
    public class AuthService : IAuthService
    {
        private readonly AuthDbContext _context;
        private readonly JwtTokenGenerator _jwt;

        public AuthService(AuthDbContext context, JwtTokenGenerator jwt)
        {
            _context = context;
            _jwt = jwt;
        }

        // REGISTER
        public async Task<User> Register(string fullName, string email, string password, string role)
        {
            var userExists = await _context.Users.AnyAsync(x => x.Email == email);

            if (userExists)
                throw new Exception("User already exists");

            var user = new User
            {
                FullName = fullName,
                Email = email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(password),
                Role = role,
                IsActive = true
            };

            _context.Users.Add(user);

            await _context.SaveChangesAsync();

            return user;
        }

        // LOGIN
        public async Task<string> Login(string email, string password)
        {
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Email == email);

            if (user == null || !user.IsActive)
                throw new Exception("Invalid credentials");

            bool isValid = BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);

            if (!isValid)
                throw new Exception("Invalid credentials");

            var token = _jwt.GenerateToken(user);

            return token;
        }

        // CREATE USER
        public async Task<User> CreateUser(string fullName, string email, string password, string role)
        {
            var userExists = await _context.Users.AnyAsync(x => x.Email == email);

            if (userExists)
                throw new Exception("User already exists");

            var user = new User
            {
                FullName = fullName,
                Email = email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(password),
                Role = role,
                IsActive = true
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return user;
        }

        // FORGOT PASSWORD
        public async Task<string> ForgotPassword(string email)
        {
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Email == email);

            if (user == null)
                throw new Exception("User not found");

            var resetToken = Guid.NewGuid().ToString();

            user.ResetToken = resetToken;
            user.ResetTokenExpiry = DateTime.UtcNow.AddHours(1);

            await _context.SaveChangesAsync();

            return resetToken;
        }

        // RESET PASSWORD
        public async Task<string> ResetPassword(string token, string newPassword)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(x => x.ResetToken == token);

            if (user == null || user.ResetTokenExpiry < DateTime.UtcNow)
                throw new Exception("Invalid or expired token");

            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(newPassword);

            user.ResetToken = null;
            user.ResetTokenExpiry = null;

            await _context.SaveChangesAsync();

            return "Password reset successful";
        }

        // LOGOUT
        public async Task Logout(string email)
        {
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Email == email);

            if (user == null)
                throw new Exception("User not found");

            user.RefreshToken = null;

            await _context.SaveChangesAsync();
        }

        // REFRESH TOKEN
        public async Task<string> RefreshToken(string refreshToken)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(x => x.RefreshToken == refreshToken);

            if (user == null)
                throw new Exception("Invalid refresh token");

            var newToken = _jwt.GenerateToken(user);

            return newToken;
        }

        // DEACTIVATE USER
        public async Task DeactivateUser(int userId)
        {
            var user = await _context.Users.FindAsync(userId);

            if (user == null)
                throw new Exception("User not found");

            user.IsActive = false;

            await _context.SaveChangesAsync();
        }

        // REACTIVATE USER
        public async Task ReactivateUser(int userId)
        {
            var user = await _context.Users.FindAsync(userId);

            if (user == null)
                throw new Exception("User not found");

            user.IsActive = true;

            await _context.SaveChangesAsync();
        }
    }
}*/