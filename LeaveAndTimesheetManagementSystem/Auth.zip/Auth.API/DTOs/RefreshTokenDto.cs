﻿namespace Auth.API.DTOs
{
    public class RefreshTokenDto
    {
        public string RefreshToken { get; set; }
    }
}
