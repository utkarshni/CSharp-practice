﻿namespace Auth.API.DTOs
{
    public class LogoutDTO
    {
        public string Email { get; set; }
    }
}
