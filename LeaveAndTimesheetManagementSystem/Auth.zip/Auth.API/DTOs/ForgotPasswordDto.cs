﻿namespace Auth.API.DTOs
{
    public class ForgotPasswordDto
    {
        public string Email { get; set; }
    }
}
