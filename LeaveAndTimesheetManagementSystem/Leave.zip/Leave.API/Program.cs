﻿using Leave.API.Data;
using Leave.API.Models;
using Leave.API.Messaging;
using Microsoft.EntityFrameworkCore;
using Leave.API.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<ILeaveRepository, LeaveRepository>();

// RabbitMQ Publisher
builder.Services.AddSingleton<RabbitMQPublisher>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseAuthorization();
app.MapControllers();
var consumer = new RabbitMQConsumer();
consumer.StartListening();

// DATA SEEDING
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    if (!context.LeaveTypes.Any())
    {
        context.LeaveTypes.AddRange(
            new LeaveType { Name = "Sick Leave", DefaultDays = 10 },
            new LeaveType { Name = "Casual Leave", DefaultDays = 7 },
            new LeaveType { Name = "Paid Leave", DefaultDays = 15 },
            new LeaveType { Name = "Maternity Leave", DefaultDays = 90 }
        );

        context.SaveChanges();
    }
}

app.Run();
