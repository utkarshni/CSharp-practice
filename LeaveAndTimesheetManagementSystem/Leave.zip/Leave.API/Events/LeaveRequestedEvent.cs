﻿namespace Leave.API.Events
{
    public class LeaveRequestedEvent
    {
        public int LeaveId { get; set; }
        public int EmployeeId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
