﻿using Leave.API.Data;
using Leave.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
[ApiController]
[Route("api/[controller]")]
public class HolidayController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public HolidayController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetHolidays()
    {
        var holidays = await _context.Holidays.ToListAsync();
        return Ok(holidays);
    }

    [HttpPost]
    public async Task<IActionResult> AddHoliday(Holiday holiday)
    {
        await _context.Holidays.AddAsync(holiday);
        await _context.SaveChangesAsync();
        return Ok(holiday);
    }
}
