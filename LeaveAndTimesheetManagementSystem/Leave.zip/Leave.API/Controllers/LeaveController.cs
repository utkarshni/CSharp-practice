﻿using Leave.API.Models;
using Leave.API.Repositories;
using Leave.API.Messaging;
using Microsoft.AspNetCore.Mvc;
using Leave.API.Events;
using Newtonsoft.Json;
namespace Leave.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LeaveController : ControllerBase
    {
        private readonly ILeaveRepository _repository;
        private readonly RabbitMQPublisher _publisher;

        public LeaveController(ILeaveRepository repository, RabbitMQPublisher publisher)
        {
            _repository = repository;
            _publisher = publisher;
        }

       /* [HttpPost]
        public async Task<IActionResult> Create(LeaveRequest leave)
        {
            await _repository.Add(leave);

            _publisher.SendMessage($"Leave Request Created for EmployeeId: {leave.EmployeeId}");

            return Ok(leave);
        }*/
        [HttpPost]
        public async Task<IActionResult> Create(LeaveRequest leave)
        {
            await _repository.Add(leave);

            var leaveEvent = new LeaveRequestedEvent
            {
                LeaveId = leave.Id,
                EmployeeId = leave.EmployeeId,
                StartDate = leave.StartDate,
                EndDate = leave.EndDate
            };

            var message = JsonConvert.SerializeObject(leaveEvent);

            _publisher.SendMessage(message);

            return Ok(leave);
        }
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var leaves = await _repository.GetAll();
            return Ok(leaves);
        }
        [HttpPut("update-status/{leaveId}")]
        public async Task<IActionResult> UpdateLeaveStatus(int leaveId, string status)
        {
            var leave = await _repository.UpdateLeaveStatus(leaveId, status);

            if (leave == null)
                return NotFound();

            return Ok(leave);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, LeaveRequest leave)
        {
            if (id != leave.Id)
                return BadRequest();

            await _repository.Update(leave);
            return Ok(leave);
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();
        }
    }
}

/*using Leave.API.Models;
using Leave.API.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace Leave.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LeaveController : ControllerBase
    {
        private readonly ILeaveRepository _repository;

        public LeaveController(ILeaveRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var leaves = await _repository.GetAll();
            return Ok(leaves);
        }

        [HttpPut("update-status/{leaveId}")]
        public async Task<IActionResult> UpdateLeaveStatus(int leaveId, string status)
        {
            var leave = await _repository.UpdateLeaveStatus(leaveId, status);

            if (leave == null)
                return NotFound();

            return Ok(leave);
        }

        [HttpPost]
        public async Task<IActionResult> Create(LeaveRequest leave)
        {
            await _repository.Add(leave);
            return Ok(leave);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, LeaveRequest leave)
        {
            if (id != leave.Id)
                return BadRequest();

            await _repository.Update(leave);
            return Ok(leave);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();
        }
    }
}*/