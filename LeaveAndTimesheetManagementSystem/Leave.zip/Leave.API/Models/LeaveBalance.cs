﻿namespace Leave.API.Models
{
    public class LeaveBalance
    {
        public int Id { get; set; }

        public int EmployeeId { get; set; }

        public int LeaveTypeId { get; set; }

        public int RemainingDays { get; set; }
    }
}
