﻿using Microsoft.EntityFrameworkCore;
using Leave.API.Models;

namespace Leave.API.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<LeaveRequest> LeaveRequests { get; set; }

        public DbSet<LeaveType> LeaveTypes { get; set; }

        public DbSet<LeaveBalance> LeaveBalances { get; set; }

        public DbSet<Holiday> Holidays { get; set; }
    }
}
