﻿using Leave.API.Models;

namespace Leave.API.Repositories
{
    public interface ILeaveRepository
    {
        Task<IEnumerable<LeaveRequest>> GetAll();

        Task<LeaveRequest> GetById(int id);

        Task Add(LeaveRequest leave);

        Task Update(LeaveRequest leave);
        Task<LeaveRequest> UpdateLeaveStatus(int leaveId, string status);
        Task Delete(int id);
    }
}
