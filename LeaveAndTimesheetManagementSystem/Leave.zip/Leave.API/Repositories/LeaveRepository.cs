﻿using Leave.API.Data;
using Leave.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Leave.API.Repositories
{
    public class LeaveRepository : ILeaveRepository
    {
        private readonly ApplicationDbContext _context;

        public LeaveRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<LeaveRequest>> GetAll()
        {
            return await _context.LeaveRequests.ToListAsync();
        }

        public async Task<LeaveRequest> GetById(int id)
        {
            return await _context.LeaveRequests.FindAsync(id);
        }

        public async Task Add(LeaveRequest leave)
        {
            await _context.LeaveRequests.AddAsync(leave);
            await _context.SaveChangesAsync();
        }

        public async Task Update(LeaveRequest leave)
        {
            _context.LeaveRequests.Update(leave);
            await _context.SaveChangesAsync();
        }
        public async Task<LeaveRequest> UpdateLeaveStatus(int leaveId, string status)
        {
            var leave = await _context.LeaveRequests.FindAsync(leaveId);

            if (leave == null)
                return null;

            leave.Status = status;

            await _context.SaveChangesAsync();

            return leave;
        }
        public async Task Delete(int id)
        {
            var leave = await _context.LeaveRequests.FindAsync(id);
            if (leave != null)
            {
                _context.LeaveRequests.Remove(leave);
                await _context.SaveChangesAsync();
            }
        }
    }
}
