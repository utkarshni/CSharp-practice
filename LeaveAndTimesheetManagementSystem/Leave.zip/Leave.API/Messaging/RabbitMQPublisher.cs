﻿using RabbitMQ.Client;
using System.Text;

namespace Leave.API.Messaging
{
    public class RabbitMQPublisher
    {
        public void SendMessage(string message)
        {
            var factory = new ConnectionFactory()
            {
                HostName = "localhost"
            };

            using var connection = factory.CreateConnection();
            using var channel = connection.CreateModel();

            channel.QueueDeclare(
                queue: "leaveRequestQueue",
                durable: false,
                exclusive: false,
                autoDelete: false,
                arguments: null);

            var body = Encoding.UTF8.GetBytes(message);

            channel.BasicPublish(
                exchange: "",
                routingKey: "leaveRequestQueue",
                basicProperties: null,
                body: body);
        }
    }
}