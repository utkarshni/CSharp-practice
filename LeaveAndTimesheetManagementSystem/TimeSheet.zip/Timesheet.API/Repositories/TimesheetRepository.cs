﻿using Microsoft.EntityFrameworkCore;
using Timesheet.API.Data;
using Timesheet.API.Models;

namespace Timesheet.API.Repositories
{
    public class TimesheetRepository : ITimesheetRepository
    {
        private readonly ApplicationDbContext _context;

        public TimesheetRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<TimesheetEntry>> GetAll()
        {
            return await _context.Timesheets.ToListAsync();
        }

        public async Task<TimesheetEntry> GetById(int id)
        {
            return await _context.Timesheets.FindAsync(id);
        }

        public async Task Add(TimesheetEntry timesheet)
        {
            await _context.Timesheets.AddAsync(timesheet);
            await _context.SaveChangesAsync();
        }
        public async Task<TimesheetEntry> UpdateStatus(int id, string status)
        {
            var timesheet = await _context.Timesheets.FindAsync(id);

            if (timesheet == null)
                return null;

            timesheet.Status = status;

            await _context.SaveChangesAsync();

            return timesheet;
        }
        public async Task Update(TimesheetEntry timesheet)
        {
            _context.Timesheets.Update(timesheet);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(int id)
        {
            var timesheet = await _context.Timesheets.FindAsync(id);

            if (timesheet != null)
            {
                _context.Timesheets.Remove(timesheet);
                await _context.SaveChangesAsync();
            }
        }
    }
}
