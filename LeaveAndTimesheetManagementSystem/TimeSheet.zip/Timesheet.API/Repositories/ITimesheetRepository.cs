﻿using Timesheet.API.Models;

namespace Timesheet.API.Repositories
{
    public interface ITimesheetRepository
    {
        Task<IEnumerable<TimesheetEntry>> GetAll();

        Task<TimesheetEntry> GetById(int id);

        Task Add(TimesheetEntry timesheet);

        Task Update(TimesheetEntry timesheet);
        Task<TimesheetEntry> UpdateStatus(int id, string status);
        Task Delete(int id);
    }
}
