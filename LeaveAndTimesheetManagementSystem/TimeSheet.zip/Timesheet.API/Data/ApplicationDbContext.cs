﻿using Microsoft.EntityFrameworkCore;
using Timesheet.API.Models;

namespace Timesheet.API.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<TimesheetEntry> Timesheets { get; set; }
    }
}
