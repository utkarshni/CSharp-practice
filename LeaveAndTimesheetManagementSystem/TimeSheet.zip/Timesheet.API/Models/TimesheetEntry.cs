﻿namespace Timesheet.API.Models
{
    public class TimesheetEntry
    {
        public int Id { get; set; }

        public int EmployeeId { get; set; }

        public DateTime Date { get; set; }

        public int HoursWorked { get; set; }

        public string TaskDescription { get; set; }

        public string Status { get; set; } // Pending / Approved
    }
}
