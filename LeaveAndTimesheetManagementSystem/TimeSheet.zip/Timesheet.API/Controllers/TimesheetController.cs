﻿using Microsoft.AspNetCore.Mvc;
using Timesheet.API.Models;
using Timesheet.API.Repositories;

namespace Timesheet.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TimesheetController : ControllerBase
    {
        private readonly ITimesheetRepository _repository;

        public TimesheetController(ITimesheetRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var timesheets = await _repository.GetAll();
            return Ok(timesheets);
        }

        [HttpPost]
        public async Task<IActionResult> Create(TimesheetEntry entry)
        {
            await _repository.Add(entry);
            return Ok(entry);
        }
        [HttpPut("update-status/{id}")]
        public async Task<IActionResult> UpdateStatus(int id, string status)
        {
            var timesheet = await _repository.UpdateStatus(id, status);

            if (timesheet == null)
                return NotFound();

            return Ok(timesheet);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, TimesheetEntry entry)
        {
            if (id != entry.Id)
                return BadRequest();

            await _repository.Update(entry);
            return Ok(entry);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repository.Delete(id);
            return Ok();
        }
    }
}
