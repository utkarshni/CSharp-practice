﻿using RabbitMQ.Client;
using System.Text;

namespace Manager.API.Messaging
{
    public class RabbitMQPublisher
    {
        public void SendMessage(string message)
        {
            var factory = new ConnectionFactory()
            {
                HostName = "localhost"
            };

            using var connection = factory.CreateConnection();
            using var channel = connection.CreateModel();

            channel.QueueDeclare(
                queue: "leaveApprovalQueue",
                durable: false,
                exclusive: false,
                autoDelete: false,
                arguments: null);

            var body = Encoding.UTF8.GetBytes(message);

            channel.BasicPublish(
                exchange: "",
                routingKey: "leaveApprovalQueue",
                basicProperties: null,
                body: body);
        }
    }
}
