﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;

namespace Manager.API.Messaging
{
    public class RabbitMQConsumer
    {
        public void StartListening()
        {
            var factory = new ConnectionFactory()
            {
                HostName = "localhost"
            };

            var connection = factory.CreateConnection();
            var channel = connection.CreateModel();

            channel.QueueDeclare(
                queue: "leaveRequestQueue",
                durable: false,
                exclusive: false,
                autoDelete: false,
                arguments: null);

            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (model, ea) =>
            {
                var body = ea.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);

                Console.WriteLine("Leave Request Received: " + message);
            };

            channel.BasicConsume(
                queue: "leaveRequestQueue",
                autoAck: true,
                consumer: consumer);
        }
    }
}