﻿using Microsoft.EntityFrameworkCore;
using Manager.API.Models;

namespace Manager.API.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Manager.API.Models.Manager> Managers { get; set; }

        public DbSet<LeaveApproval> LeaveApprovals { get; set; }
    }
}
