﻿using Manager.API.Data;
using Manager.API.Models;
using Manager.API.Repositories;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;

namespace Manager.API.Services
{
    public class ManagerService : IManagerService
    {
        private readonly IManagerRepository _managerRepository;
        private readonly ApplicationDbContext _context;
        private readonly IHttpClientFactory _httpClientFactory;

        public ManagerService(
            IManagerRepository managerRepository,
            ApplicationDbContext context,
            IHttpClientFactory httpClientFactory)
        {
            _managerRepository = managerRepository;
            _context = context;
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IEnumerable<Manager.API.Models.Manager>> GetManagers()
        {
            return await _managerRepository.GetManagers();
        }
        public async Task<bool> ApproveTimesheet(int timesheetId)
        {
            var client = _httpClientFactory.CreateClient();

            var response = await client.PutAsync(
                $"http://localhost:5083/api/timesheet/update-status/{timesheetId}?status=Approved",
                null);

            return response.IsSuccessStatusCode;
        }

        public async Task<bool> RejectTimesheet(int timesheetId)
        {
            var client = _httpClientFactory.CreateClient();

            var response = await client.PutAsync(
                $"http://localhost:5083/api/timesheet/update-status/{timesheetId}?status=Rejected",
                null);

            return response.IsSuccessStatusCode;
        }
        public async Task<Manager.API.Models.Manager> GetManagerByEmployeeId(int employeeId)
        {
            return await _managerRepository.GetManagerByEmployeeId(employeeId);
        }

        public async Task<Manager.API.Models.Manager> AddManager(Manager.API.Models.Manager manager)
        {
            return await _managerRepository.AddManager(manager);
        }

        public async Task<bool> ManagerExists(int employeeId)
        {
            return await _managerRepository.ManagerExists(employeeId);
        }

        // APPROVE LEAVE
        public async Task<LeaveApproval> ApproveLeave(int leaveRequestId, int managerId)
        {
            var approval = new LeaveApproval
            {
                LeaveId = leaveRequestId,
                ManagerId = managerId,
                Status = "Approved",
                ActionDate = DateTime.UtcNow
            };

            await _context.LeaveApprovals.AddAsync(approval);
            await _context.SaveChangesAsync();

            // 🔹 Call Leave API
            var client = _httpClientFactory.CreateClient();

            var response = await client.PutAsync(
                $"https://localhost:7096/api/leave/update-status/{leaveRequestId}?status=Approved",
                null);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Failed to update leave status in Leave API");
            }

            return approval;
        }

        // REJECT LEAVE
        public async Task<LeaveApproval> RejectLeave(int leaveRequestId, int managerId)
        {
            var approval = new LeaveApproval
            {
                LeaveId = leaveRequestId,
                ManagerId = managerId,
                Status = "Rejected",
                ActionDate = DateTime.UtcNow
            };

            await _context.LeaveApprovals.AddAsync(approval);
            await _context.SaveChangesAsync();

            // 🔹 Call Leave API
            var client = _httpClientFactory.CreateClient();

            var response = await client.PutAsync(
                $"https://localhost:7096/api/leave/update-status/{leaveRequestId}?status=Rejected",
                null);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Failed to update leave status in Leave API");
            }

            return approval;
        }
    }
}
