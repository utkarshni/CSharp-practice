﻿using Manager.API.Models;

namespace Manager.API.Services
{
    public interface IManagerService
    {
        Task<IEnumerable<Manager.API.Models.Manager>> GetManagers();

        Task<Manager.API.Models.Manager> GetManagerByEmployeeId(int employeeId);
        Task<LeaveApproval> ApproveLeave(int leaveRequestId, int managerId);

        Task<LeaveApproval> RejectLeave(int leaveRequestId, int managerId);
        Task<Manager.API.Models.Manager> AddManager(Manager.API.Models.Manager manager);
        Task<bool> ApproveTimesheet(int timesheetId);

        Task<bool> RejectTimesheet(int timesheetId);
        Task<bool> ManagerExists(int employeeId);
    }
}
