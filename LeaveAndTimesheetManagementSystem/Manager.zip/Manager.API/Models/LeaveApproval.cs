﻿namespace Manager.API.Models
{
    public class LeaveApproval
    {
        public int Id { get; set; }

        public int LeaveId { get; set; }

        public int ManagerId { get; set; }

        public string Status { get; set; }

        //public string Comments { get; set; }
        public DateTime ActionDate { get; set; }
    }
}
