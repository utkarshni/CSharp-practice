﻿namespace Manager.API.Models
{
    public class Manager
    {
        public int Id { get; set; }

        public int EmployeeId { get; set; }

        public string Department { get; set; }

        public bool IsActive { get; set; }
    }
}
