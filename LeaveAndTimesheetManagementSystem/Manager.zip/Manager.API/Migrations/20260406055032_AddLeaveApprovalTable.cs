﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Manager.API.Migrations
{
    /// <inheritdoc />
    public partial class AddLeaveApprovalTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Comments",
                table: "LeaveApprovals");

            migrationBuilder.AddColumn<DateTime>(
                name: "ActionDate",
                table: "LeaveApprovals",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ActionDate",
                table: "LeaveApprovals");

            migrationBuilder.AddColumn<string>(
                name: "Comments",
                table: "LeaveApprovals",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
