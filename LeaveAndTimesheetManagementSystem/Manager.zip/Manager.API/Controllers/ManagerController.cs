﻿using Manager.API.Models;
using Manager.API.Services;
using Microsoft.AspNetCore.Mvc;
using Manager.API.Messaging;
using Manager.API.Events;
using Newtonsoft.Json;
namespace Manager.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManagerController : ControllerBase
    {
        private readonly IManagerService _managerService;

        public ManagerController(IManagerService managerService)
        {
            _managerService = managerService;
        }

        [HttpGet]
        public async Task<IActionResult> GetManagers()
        {
            var managers = await _managerService.GetManagers();
            return Ok(managers);
        }
        [HttpPost("approve-leave")]
        public async Task<IActionResult> ApproveLeave(int leaveRequestId, int managerId)
        {
            var result = await _managerService.ApproveLeave(leaveRequestId, managerId);
            return Ok(result);
        }
        [HttpPost("approve")]
        public IActionResult ApproveLeave(int leaveId)
        {
            var publisher = new RabbitMQPublisher();

            var approvalEvent = new LeaveApprovalEvent
            {
                LeaveId = leaveId,
                Status = "Approved"
            };

            var message = JsonConvert.SerializeObject(approvalEvent);

            publisher.SendMessage(message);

            return Ok("Leave Approved");
        }
        [HttpPost("reject-leave")]
        public async Task<IActionResult> RejectLeave(int leaveRequestId, int managerId)
        {
            var result = await _managerService.RejectLeave(leaveRequestId, managerId);
            return Ok(result);
        }
        [HttpPut("approve-timesheet")]
        public async Task<IActionResult> ApproveTimesheet(int timesheetId)
        {
            var result = await _managerService.ApproveTimesheet(timesheetId);

            if (!result)
                return BadRequest("Approval failed");

            return Ok("Timesheet Approved");
        }

        [HttpPut("reject-timesheet")]
        public async Task<IActionResult> RejectTimesheet(int timesheetId)
        {
            var result = await _managerService.RejectTimesheet(timesheetId);

            if (!result)
                return BadRequest("Rejection failed");

            return Ok("Timesheet Rejected");
        }
        [HttpGet("{employeeId}")]
        public async Task<IActionResult> GetManager(int employeeId)
        {
            var manager = await _managerService.GetManagerByEmployeeId(employeeId);

            if (manager == null)
                return NotFound();

            return Ok(manager);
        }

        [HttpPost]
        public async Task<IActionResult> AddManager([FromBody] Manager.API.Models.Manager manager)
        {
            var createdManager = await _managerService.AddManager(manager);
            return Ok(createdManager);
        }
    }
}
