using Manager.API.Data;
using Microsoft.EntityFrameworkCore;
using Manager.API.Repositories;
using Manager.API.Services;
using Manager.API.Messaging;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddHttpClient();

builder.Services.AddScoped<IManagerRepository, ManagerRepository>();
builder.Services.AddScoped<IManagerService, ManagerService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// RabbitMQ Publisher
builder.Services.AddSingleton<RabbitMQPublisher>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseAuthorization();

app.MapControllers();


// Start RabbitMQ Consumer (Saga)
var consumer = new RabbitMQConsumer();
consumer.StartListening();

app.Run();
/*using Manager.API.Data;
using Microsoft.EntityFrameworkCore;
using Manager.API.Repositories;
using Manager.API.Services;
using Manager.API.Messaging;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddHttpClient();
builder.Services.AddScoped<IManagerRepository, ManagerRepository>();
builder.Services.AddScoped<IManagerService, ManagerService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Start RabbitMQ Consumer
var consumer = new RabbitMQConsumer();
consumer.StartListening();

app.UseSwagger();
app.UseSwaggerUI();

app.UseAuthorization();

app.MapControllers();

app.Run();*/
