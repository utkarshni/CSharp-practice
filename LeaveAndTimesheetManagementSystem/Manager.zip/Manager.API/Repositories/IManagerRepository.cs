﻿using Manager.API.Models;

namespace Manager.API.Repositories
{
    public interface IManagerRepository
    {
        Task<IEnumerable<Manager.API.Models.Manager>> GetManagers();

        Task<Manager.API.Models.Manager> GetManagerByEmployeeId(int employeeId);

        Task<Manager.API.Models.Manager> AddManager(Manager.API.Models.Manager manager);

        Task<bool> ManagerExists(int employeeId);
    }
}
