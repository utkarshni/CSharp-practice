﻿using Manager.API.Data;
using Manager.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Manager.API.Repositories
{
    public class ManagerRepository : IManagerRepository
    {
        private readonly ApplicationDbContext _context;

        public ManagerRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Manager.API.Models.Manager>> GetManagers()
        {
            return await _context.Managers.ToListAsync();
        }

        public async Task<Manager.API.Models.Manager> GetManagerByEmployeeId(int employeeId)
        {
            return await _context.Managers
                .FirstOrDefaultAsync(m => m.EmployeeId == employeeId);
        }

        public async Task<Manager.API.Models.Manager> AddManager(Manager.API.Models.Manager manager)
        {
            _context.Managers.Add(manager);
            await _context.SaveChangesAsync();
            return manager;
        }

        public async Task<bool> ManagerExists(int employeeId)
        {
            return await _context.Managers
                .AnyAsync(m => m.EmployeeId == employeeId);
        }
    }
}
