﻿namespace Manager.API.Events
{
    public class LeaveApprovalEvent
    {
        public int LeaveId { get; set; }
        public string Status { get; set; }
    }
}
